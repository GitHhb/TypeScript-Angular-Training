import { RandomizePipe } from './randomize.pipe';

describe('RandomizePipe', () => {
  it('create an instance', () => {
    const pipe = new RandomizePipe();
    expect(pipe).toBeTruthy();
  });
});
